<?php
    require_once 'Conexion.php';
    require_once 'Documento.php';
    require_once 'Libro.php';
    require_once 'Revista.php';
    require_once 'Multimedia.php';

    // Creamos la conexion
    $conexion = new Conexion();
    $db = $conexion->conexion();

    // Creamos los objetos
    $libro = new Libro($db);
    $revista = new Revista($db);
    $multimedia = new Multimedia($db);

    // Aplicamos métodos para mostrar el contenido de las tablas
    $libros = $libro->mostrar();
    $revistas = $revista->mostrar();
    $multimedias = $multimedia->mostrar();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Listado de recursos</title>
    <style>
        /* Estilos generales */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h1 {
            color: #333;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }

        .recurso {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .recurso p {
            margin: 0;
            font-size: 16px;
            color: #555;
        }

        .recurso p strong {
            color: #333;
        }

        /* Estilos para los títulos de sección */
        .seccion {
            margin-top: 30px;
        }

        /* Estilos para el contenedor principal */
        .contenedor {
            max-width: 800px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <a href="menuUsuario.php">Volver</a><br>
    <a href="cerrarSesion.php">Cerrar sesion</a>
    <div class="contenedor">
        <div class="seccion">
            <h1>Libros</h1>
            <?php while ($row = $libros->fetch(PDO::FETCH_ASSOC)): ?>
                <div class="recurso">
                    <p><strong>Título:</strong> <?php echo $row['titulo']; ?></p>
                    <p><strong>Autores:</strong> <?php echo $row['listaautores']; ?></p>
                    <p><strong>ISBN:</strong> <?php echo $row['isbn']; ?></p>
                </div>
            <?php endwhile; ?>
        </div>
        <div class="seccion">
            <h1>Revistas</h1>
            <?php while ($row = $revistas->fetch(PDO::FETCH_ASSOC)): ?>
                <div class="recurso">
                    <p><strong>Título:</strong> <?php echo $row['titulo']; ?></p>
                    <p><strong>Autores:</strong> <?php echo $row['listaautores']; ?></p>
                    <p><strong>Frecuencia:</strong> <?php echo $row['frecuencia']; ?></p>
                </div>
            <?php endwhile; ?>
        </div>
        <div class="seccion">
            <h1>Multimedia</h1>
            <?php while ($row = $multimedias->fetch(PDO::FETCH_ASSOC)): ?>
                <div class="recurso">
                    <p><strong>Título:</strong> <?php echo $row['titulo']; ?></p>
                    <p><strong>Autores:</strong> <?php echo $row['listaautores']; ?></p>
                    <p><strong>Formato:</strong> <?php echo $row['formato']; ?></p>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>
