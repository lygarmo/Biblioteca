<?php
session_start();

$email = '';
$clave = '';

if (isset($_POST['login'])) {
    // Obtener los datos del formulario
    $email = $_POST['email'];
    $clave = $_POST['clave'];
}

// Si es admin directamente nos redirige
if ($email === 'admin' && $clave === 'admin') {
    $_SESSION['id'] = 'admin'; 
    header("Location: menuAdmin.php");
    exit;  
}

require_once 'Conexion.php';
require_once 'Usuario.php';

// Creamos la conexión
$conexion = new Conexion();
$conexion = $conexion->conexion();

$usuario = new Usuario($conexion);
$resultadoConsulta = $usuario->autenticarUsuario($email, $clave);

if ($resultadoConsulta) {
    $_SESSION['idusuario'] = $resultadoConsulta['idusuario']; // Guardar el ID del usuario en la sesión
    // Si el usuario es autenticado
    header("Location: menuUsuario.php");
    exit;
} else {
    // Si no existe el usuario o la contraseña es incorrecta
    echo "Usuario o contraseña incorrectos.";
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Inicio de sesión</title>
    <link rel='stylesheet' type='text/css' media='screen' href='estilos.css'>
</head>
<body>
    <h1>Bienvenido a la biblioteca municipal</h1>
    <h2>Login</h2>
    <form method="POST">
        Email: <input type="text" name="email" required><br>
        Clave: <input type="password" name="clave" required><br>
        <button type="submit" name="login">Entrar</button>
    </form>

    <h2>¿No tienes cuenta? Regístrate</h2>
    <a href="Registro.php">Regístrate</a>
</body>
</html>