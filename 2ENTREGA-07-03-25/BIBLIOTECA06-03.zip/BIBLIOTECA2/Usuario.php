<?php
    class Usuario{
        private $conexion;

        // Constructor
        public function __construct($db){
            $this->conexion = $db;
        }

        // Método para obtener usuarios
        public function obtenerUsuarios(){
            $consulta = "SELECT * FROM usuario";
            $stmt = $this->conexion->prepare($consulta);
            $stmt->execute();
            return $stmt;
        }

        // Método para insertar un nuevo usuario
        public function insertarUsuario($nombre, $curso, $email, $direccion, $clave, $telefono){
            $consulta = "INSERT INTO usuario (nombre, curso, email, direccion, clave, telefono) VALUES 
                (:nombre, :curso, :email, :direccion, :clave, :telefono)";
            $stmt = $this->conexion->prepare($consulta);

            $stmt->bindParam(':nombre', $nombre);
            $stmt->bindParam(':curso', $curso);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':direccion', $direccion);
            $stmt->bindParam(':clave', $clave);
            $stmt->bindParam(':telefono', $telefono);

            $stmt->execute();
            return $stmt;
        }

        // Método para autenticar usuario
        public function autenticarUsuario($usuario, $clave){
            $consulta = "SELECT * FROM usuario WHERE email = :email AND clave = :clave";
            $stmt = $this->conexion->prepare($consulta);

            $stmt->bindParam(':email', $usuario);
            $stmt->bindParam(':clave', $clave);

            $stmt->execute();

            // Si el usuario existe, devuelve el resultado
            if ($stmt->rowCount() > 0) {
                $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
                return $resultado; // Devuelve los datos del usuario
            } else {
                return null; // Usuario no encontrado
            }
        }

        public function saberPrestamos($idusuario){
            $consulta = "SELECT * FROM prestamo WHERE idusuario = :idusuario";
            $stmt = $this->conexion->prepare($consulta);

            $stmt->bindParam(':idusuario', $idusuario);

            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }
?>
